package cn.snowflake.rose.events.impl;

import com.darkmagician6.eventapi.events.Event;

public class EventUpdate implements Event {
}
