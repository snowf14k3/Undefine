package cn.snowflake.rose.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

//Coded for SNOW_FLAKES.
public class JReflectUtility {
    //Cache fields and methods makes less work finding them.
    private static Map<String, Field> cachedFields;
    private static Map<String, Method> cachedMethods;


    public static Object getMethodAsObject(Class<?> inClass, String name,
                                           boolean secureAccess, Object... parameter) {
        try {
            return Objects.requireNonNull(getMethod(inClass, name, secureAccess))
                    .invoke(inClass.newInstance(), parameter);
        } catch (IllegalAccessException | InvocationTargetException
                | InstantiationException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static Object getMethodAsObject(Class<?> inClass, Object instance,
                                           String name, Object... parameter){
        try{
            return Objects.requireNonNull(getMethod(inClass, name, true))
                    .invoke(instance, parameter);
        }catch (IllegalAccessException | InvocationTargetException e){
            e.printStackTrace();
            return null;
        }
    }

    public static Object getMethodAsObject(Class<?> inClass, Object instance,
                                           String name, boolean secureAccess, Object... parameter){
        try{
            return Objects.requireNonNull(getMethod(inClass, name, secureAccess))
                    .invoke(instance, parameter);
        }catch (IllegalAccessException | InvocationTargetException e){
            e.printStackTrace();
            return null;
        }
    }

    public static Method getMethod(Class<?> inClass, String name, boolean secureAccess){
        if(cachedMethods.containsKey(getUniquePath(inClass, name)))
            return cachedMethods.get(getUniquePath(inClass, name));

        for (Method method : inClass.getDeclaredMethods())
            if(method.getName().equals(name)) {
                if(secureAccess && !method.isAccessible())
                    method.setAccessible(true);
                cachedMethods.put(getUniquePath(inClass, name), method);
                return method;
            }
        return null;
    }

    //We don't provide auto-instance-generator for fields.
    //Non-static fields may be not init-ed
    public static boolean getFieldAsBoolean(Class<?> inClass, Object instance, String name){
        try{
            //All of them requires to not be null.
            return Objects.requireNonNull(getField(inClass, name, true)).getBoolean(instance);
        }catch (IllegalAccessException e){
            e.printStackTrace();
            return false;
        }
    }

    public static boolean getFieldAsBoolean(Class<?> inClass, Object instance, String name,
                                            boolean secureAccess){
        try{
            return Objects.requireNonNull(getField(inClass, name,secureAccess)).getBoolean(instance);
        }catch (IllegalAccessException e){
            e.printStackTrace();
            return false;
        }
    }

    public static Object getFieldAsObject(Class<?> inClass, Object instance, String name){
        try{
            return Objects.requireNonNull(getField(inClass, name, true)).get(instance);
        }catch (IllegalAccessException e){
            e.printStackTrace();
            return false;
        }
    }

    public static Object getFieldAsObject(Class<?> inClass, Object instance, String name,
                                          boolean secureAccess){
        try{
            return Objects.requireNonNull(getField(inClass, name, secureAccess)).get(instance);
        }catch (IllegalAccessException e){
            e.printStackTrace();
            return false;
        }
    }

    public static void setField(Class<?> inClass, Object instance, String name, Object to){
        try{
            Objects.requireNonNull(getField(inClass, name, true)).set(instance, to);
        }catch (IllegalAccessException e){
            e.printStackTrace();
        }
    }

    public static Field getField(Class<?> inClass, String name, boolean secureAccess){
        if(cachedFields.containsKey(getUniquePath(inClass, name)))
            return cachedFields.get(getUniquePath(inClass, name));

        for (Field field : inClass.getDeclaredFields())
            if(field.getName().equals(name)) {
                if(secureAccess && !field.isAccessible())
                    field.setAccessible(true);
                cachedFields.put(getUniquePath(inClass, name), field);
                return field;
            }
        return null;
    }

    private static String getUniquePath(Class klass, String name){
        return klass.getName().replace(".", "/") + "-" + name;
    }

    //If you edited some classes, then,
    //you might have to refresh the caches.
    public static void cleanCachedMethodsAndFields(){
        cachedMethods.clear();
        cachedFields.clear();
    }

    static{
        cachedFields = new HashMap<>();
        cachedMethods = new HashMap<>();
    }

    public static Class getCPacketInjectDetect(){
        try {
            return Class.forName("luohuayu.anticheat.message.CPacketInjectDetect");
        } catch (ClassNotFoundException e) {

        }
        return null;
    }
    public static Class getEntityNumber(){
        try {
            return Class.forName("nianshow.nshowmod.entity.EntityNumber");
        } catch (ClassNotFoundException e) {

        }
        return null;
    }

    public static Class getNPCEntity(){
        try {
            return Class.forName("noppes.npcs.entity.EntityNPCInterface");
        } catch (ClassNotFoundException e) {
        }
        return null;
    }
}

