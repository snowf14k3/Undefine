package cn.snowflake.rose.utils;

import cn.snowflake.rose.Client;
import net.minecraft.client.Minecraft;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionHelper {

    public static void setField(Class clazz, Object object, Object value, String srg,String mcp){
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; ++i) {
            String name = "";
            if (Client.isSRG){
                name = srg;
            }else{
                name = mcp;
            }
            if (!fields[i].getName().equals(name)) continue;
            ReflectionHelper.setField(clazz, object, i, value);
            return;
        }
    }

    public static float getcurBlockDamageMP(){
        try {
            if (Client.isSRG){
                Class clazz = Minecraft.getMinecraft().playerController.getClass();
                Field f = clazz.getDeclaredField("field_78770_f");
                f.setAccessible(true);
                return (float) f.get(Minecraft.getMinecraft().playerController.getClass());
            }else{
                Class clazz = Minecraft.getMinecraft().playerController.getClass();
                Field f = clazz.getDeclaredField("curBlockDamageMP");
                f.setAccessible(true);
                return (float) f.get(Minecraft.getMinecraft().playerController.getClass());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    public static boolean getHittingBlock(){
        try {
            if (Client.isSRG){
                Class clazz = Minecraft.getMinecraft().playerController.getClass();
                Field f = clazz.getDeclaredField("field_78778_j");
                f.setAccessible(true);
                return (f != null && f.getBoolean(Minecraft.getMinecraft().playerController.getClass()));
            }else{
                Class clazz = Minecraft.getMinecraft().playerController.getClass();
                Field f = clazz.getDeclaredField("isHittingBlock");
                f.setAccessible(true);
                return (f != null && f.getBoolean(Minecraft.getMinecraft().playerController.getClass()));
            }
        }catch (Exception e){
            e.printStackTrace();

        }
        return false;
    }

    public static void setField(Class clazz, Object o, String s, Object val) {
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; ++i) {
            if (!fields[i].getName().equals((Object)s)) continue;
            ReflectionHelper.setField(clazz, o, i, val);
            return;
        }
    }

    public static void setStringFieldWW(Class clazz, Object o, String s, Object val) {
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; ++i) {
            if (!fields[i].getName().equals((Object)s)) continue;
            ReflectionHelper.setField(clazz, o, i, val);
            return;
        }
    }

    public static void setField(Class c, Object o, int n, Object val) {
        try {
            Field field = c.getDeclaredFields()[n];
            field.setAccessible(true);
            Field modifiers = field.getClass().getDeclaredField("modifiers");
            modifiers.setAccessible(true);
            modifiers.setInt((Object)field, field.getModifiers() & 0xFFFFFFEF);
            field.set(o, val);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }



}
