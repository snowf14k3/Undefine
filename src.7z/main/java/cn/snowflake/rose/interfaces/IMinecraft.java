package cn.snowflake.rose.interfaces;

public interface IMinecraft {

    int getDebugFPS(int fps);
}
