package cn.snowflake.rose.mod.mods.PLAYER;

import cn.snowflake.rose.events.impl.EventUpdate;
import cn.snowflake.rose.mod.Category;
import cn.snowflake.rose.mod.Module;
import cn.snowflake.rose.utils.ReflectionHelper;
import com.darkmagician6.eventapi.EventTarget;


public class FastPlace extends Module {

    public FastPlace() {
        super("FastPlace", Category.PLAYER);
    }

    @EventTarget
    public void OnUpdate(EventUpdate e) {
        ReflectionHelper.setField(mc.getClass(),mc,0,"field_71467_ac","rightClickDelayTimer");
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        ReflectionHelper.setField(mc.getClass(),mc,6,"field_71467_ac","rightClickDelayTimer");
        super.onDisable();
    }

}