package cn.snowflake.rose.mod;

public enum Category {
    COMBAT,MOVEMENT,PLAYER,RENDER,WORLD;
}
