package cn.snowflake.rose;


public class Test {

    public static void main(String[] args){

    }


    private void r(String e){
        if (e.startsWith("Illegal stance")){
            return;
        }
    }

}
